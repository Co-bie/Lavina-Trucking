import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Camera, Upload } from "lucide-react";

export default function ProfilePage() {
  const [profilePic, setProfilePic] = useState<string | null>(null);
  const [licensePic, setLicensePic] = useState<string | null>(null);

  const handleProfileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = URL.createObjectURL(e.target.files[0]);
      setProfilePic(file);
    }
  };

  const handleLicenseUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = URL.createObjectURL(e.target.files[0]);
      setLicensePic(file);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#1e786c] to-[#cfab3d] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl p-8 sm:p-12 relative">
        <div className="flex flex-col items-center mb-10">
          <div className="relative group">
            <Avatar className="w-32 h-32 border-4 border-[#cfab3d] shadow-lg">
              {profilePic ? (
                <AvatarImage src={profilePic} alt="Profile" />
              ) : (
                <AvatarFallback className="text-[#1e786c] font-bold text-2xl">
                  NL
                </AvatarFallback>
              )}
            </Avatar>

            <label
              htmlFor="profile-upload"
              className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 rounded-full cursor-pointer transition"
            >
              <Camera className="text-white w-8 h-8" />
              <input
                id="profile-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleProfileUpload}
              />
            </label>
          </div>
          <p className="mt-3 font-semibold text-gray-700">Profile Picture</p>
        </div>

        <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-5">
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Name
              </label>
              <Input
                type="text"
                id="name"
                name="name"
                placeholder="Enter your full name"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>

            <div>
              <label
                htmlFor="age"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Age
              </label>
              <Input
                type="number"
                id="age"
                name="age"
                placeholder="Enter your age"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>

            <div>
              <label
                htmlFor="contact"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Contact Number
              </label>
              <Input
                type="tel"
                id="contact"
                name="contact"
                placeholder="+63 900 000 0000"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>

            <div>
              <label
                htmlFor="address"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Address
              </label>
              <Input
                type="text"
                id="address"
                name="address"
                placeholder="Enter your address"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>

            <div>
              <label
                htmlFor="emergencyName"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Emergency Contact Name
              </label>
              <Input
                type="text"
                id="emergencyName"
                name="emergencyName"
                placeholder="Full name"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>

            <div>
              <label
                htmlFor="emergencyContact"
                className="block text-sm font-bold text-[#1e786c] mb-1"
              >
                Emergency Contact Number
              </label>
              <Input
                type="tel"
                id="emergencyContact"
                name="emergencyContact"
                placeholder="+63 900 000 0000"
                className="border-[#cfab3d] focus:ring-[#1e786c]"
              />
            </div>
          </div>

          <div className="flex flex-col items-center justify-center border-2 border-dashed border-[#cfab3d] rounded-xl p-6 relative bg-gray-50 hover:bg-gray-100 transition cursor-pointer">
            {licensePic ? (
              <img
                src={licensePic}
                alt="Driver License"
                className="w-full h-72 object-cover rounded-lg shadow-md"
              />
            ) : (
              <div className="flex flex-col items-center text-gray-500">
                <Upload className="w-10 h-10 mb-3 text-[#1e786c]" />
                <p className="font-medium">Drag & Drop or Click to Upload</p>
                <p className="text-sm text-gray-400">Driver’s License Photo</p>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              className="absolute inset-0 opacity-0 cursor-pointer"
              onChange={handleLicenseUpload}
            />
          </div>
        </form>

        <div className="mt-10 text-center">
          <Button className="bg-gradient-to-r from-[#1e786c] to-[#cfab3d] text-white font-bold px-8 py-3 rounded-full hover:scale-105 hover:shadow-lg transition">
            Save Profile
          </Button>
        </div>
      </div>
    </main>
  );
}
